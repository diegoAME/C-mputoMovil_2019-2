//CLASE DE 25 DE FEBRERO DE 2019

import UIKit

let age = 38
let months = 6
let name = "Marduk"
let firstName = "Perez de Lara"
let lastName = "Dominguez"
let birthday = Date(timeIntervalSinceNow: 3600)
let isHappy = true

func hello(name nombre:String){ //_ para eliminar etiqueta; nombre: para etiquetar al parametro
    print ("Hola " + nombre)
    print("Hola \(name)")
    print ("Hola",name)
}

/* ya no se renombra al parametro, y el parametro se llama igual al de dentro de la funcion
 
    func hello(name:String){
        print ("Hola " + name)
        print("Hola \(name)")
        print ("Hola",name)
    }*/


/* FUNCION QUE DEVUELVE VALOR
 
 func hello(name:String) ->String{
 let saludo = "Hola " + name
 return saludo
 }*/

//let saludo = hello(name:name)
hello(name:"Mariana")

print(birthday)
