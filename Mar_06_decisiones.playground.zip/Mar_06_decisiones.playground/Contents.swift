import UIKit
import Foundation

/* OPERADORES LOGICOS
 
 >
 >=
 <
 <=
 ==
 !=
 
 */


/* ----------E1 -----------------------------------------
 
"hola" > "Hola"     // true
"adios" < "hola"    //true

var str = "Hello, playground"

let videoLength = 10
let videoLengthTooShortReaction = "¡Parpadeo y me lo pierdo!"
let videoReasonableLengthReaction = "Es muy bueno."
let videoMessage = "El video dura \(videoLength) (duración del video) segundos. \(videoLengthTooShortReaction)"

//if siemore se ejecuta cuando el valor de la condicion es verdadero
if videoLength < 10 {
    print(videoLengthTooShortReaction)
}

else if videoLength > 500 {
    print ("Demasiado largo!")
}

else {
    print(videoReasonableLengthReaction)
}
*/


/*-------- E2 -----------------------------
 
let bandMemberCount = 5
let gearWeight = 600
let weightPerPerson = 50
let maximumTripCount = 2

func bandCanCarryGear(bandMemberCount: Int, gearWeight: Int) -> Bool {
    
    let bandMemberCount = 5
    let weightPerPerson
    
}

 */

/*------- E3 ----------------------------
 
let a = 20
let b = 30
let c = 20

//Si a es igual a c, imprimir "a y c son iguales"
if a == c {
    print("a y c son iguales")
}

//Si a es menor que b, imprimir "b está delante de a"
if a < b {
    print("b está delante de a")
}

//Si b es mayor que a, imprimir "a pierde contra b"
if b > a {
    print("a pierde contra b")
}

//Si a es menor o igual que c, imprimir "a pierde o empata con c"
if a <= c {
    print("a pierde o empata con c")
}
 */


/*-----E4 --------------------------------
 
let  secretWord = "banana"
let guess = "manzana"

if secretWord == guess {
    print("adivinaste.")
}
else {
print("No adivinaste.")
}
 */


/* -----E5---------------------------------
 
 Operador Módulo -> %
Nos dice si un numero es divisible entre otro
 
 
¿El año es divisible por 4?
 -De ser así, ¿es divisible por 100?
 -De no ser así, es jn año bisiesto.
 -De ser así, ¿es divisible por 400?
 -De no ser así, **no** es un año bisiesto.
 -De ser así, es un año bisiesto.
 

func isLeapYear(_ year: Int) -> Bool {
    
    if (year % 4) == 0{
        if (year % 100) == 0 {
            return true
        }
    }
    
    else if (year % 400) == 0 {
        return true
    }
    
    return false
}

isLeapYear(2000)
 
 */

/* ------Inicializadores y objetos---------------

var magic = "Ahora lo ves"


//metodos para los objetos tipo string
magic.isEmpty
magic.removeAll()
magic.isEmpty
magic

var numero = 2

var nombre = String() //inicializador de tipo string, nombre es un string con cadena vacia
let nombre2 = String("Diego") //nombre2 inicia con la cadena Diego

 */

/* ------ E6 ------------- Arreglos
 
 var compras = ["maquillaje", "zapatos", "computadora"]
 
 compras.count
 compras.append("bolsas")
 compras.insert("iphone", at: 0)
 compras += ["chamarra", "falda", "reloj"]
 compras.remove(at: 0)
 compras
 
 compras[0]
 compras.removeAll()
 */



/* ----E7 ---------------------
 
 let friends = ["Manuel", "Juan"]
 
 for friend in friends {
    let sparklyFriend = "\(friend)"
    print("Oye, \(sparklyFriend), te invito a mi fiesta el viernes!")
 }
 
 friends.forEach { (friend) in
    print(friend)
 }
 
 friends[0] = "Pedro"
 */
