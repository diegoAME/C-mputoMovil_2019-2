import UIKit

//Inferencia de tipo -> var str = 4                 //identificador "str" de tipo var
//Marcado de tipo
var str:String = "Hola"
let constant = "Adios"                              //identificador "constant" de tipo let (constante)
let number = 6
//str = str + " " + constant                        //Concatenación
str = "\(str) \(constant) \(number)"                //Interpolación
print(str)
//let 😆 = "Risa 😆"
//print(😆)
